function hello() {
    // TODO: improve this
    console.log("hello world");
}

function goodbye() {
    console.log("goodbye");
}
